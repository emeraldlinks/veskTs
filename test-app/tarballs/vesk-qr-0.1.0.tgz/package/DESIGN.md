# vesk-qr — Design

## Overview

`vesk-qr` is Cofoundr's proprietary generative QR code library for the Vesk ecosystem. It separates **encoding** (what the QR says) from **rendering** (how it looks) so the Cofoundr architectural identity can be applied consistently across versions, error-correction levels, and output formats.

## Core Principles

1. **Encoding independent of rendering.** The encoder produces a boolean matrix + enriched cell map (versions 1–40, EC L/M/Q/H, numeric/alphanumeric/byte). It knows nothing about colour, shape, connectors, or finder styling.

2. **Architectural design system.** Six geometric identities built from one engine:
   - Module shapes: square, small-square, rounded-square, micro-square, circle, rectangle, combination
   - Nested-square finder patterns (2–5 concentric layers)
   - Architectural connectors (blueprint-style thin lines in inter-module whitespace)
   - Micro-details: dots, micro-squares, lines, corners
   - Alignment patterns per ISO/IEC 18004

3. **Six presets as configs of one engine.** Not six implementations. Each preset is a `QRPresetConfig` merged over user style.

4. **Deterministic seed-based generation.** xorshift128+ PRNG seeded from `hash(payload) ⨯ userSeed`. Same payload + config + seed → identical output.

5. **Quiet zone of 4 modules never decorated.** Per QR spec, never painted over.

6. **SVG primary output; PNG/WebP/PDF export.** SVG is the canonical format; raster/PDF are derived.

7. **Independent scan validation with reject-or-fallback gate.** Every generated QR is decoded by an independent decoder (@zxing). On failure, the generator auto-falls back to the minimal preset (square modules, no connectors/details) and re-validates.

8. **Plugin system.** Custom renderers/effects/colours/exports via `QRPlugin`.

## File Layout

```
src/
  index.ts            # main barrel (CofoundrMatrix, generate, types, errors)
  index.client.ts     # browser entry (canvas PNG/WebP via OffscreenCanvas)
  index.server.ts     # Node entry (SVG + PDF; canvas optional for raster)
  types.ts            # all public TS types (no `any`)
  errors.ts           # QRError, QREncodingError, ScanReliabilityError, InvalidConfigError
  cofoundr-matrix.ts  # generate() API + QRResultImpl class
  encoding/
    qr-encoder.ts     # qrcode-generator wrapper (encoding-only)
    matrix.ts         # enriched module map + cell classification
    payload.ts        # URL / vCard / Wi-Fi / text payload builders
    index.ts          # barrel
  generative/
    seeded-rng.ts     # xorshift128+ PRNG
    treatment-plan.ts # deterministic visual treatment plan
    index.ts          # barrel
  geometry/
    modules.ts        # module shape renderers
    finder.ts         # nested-square / standard finder patterns
    alignment.ts      # alignment patterns + spec coordinates
    connectors.ts     # architectural connectors + safe filtering
    micro-details.ts  # micro-detail elements + safe filtering
    generator.ts      # combines all geometry into QRShapeOp[]
    index.ts          # barrel
  rendering/
    svg.ts            # SVG renderer (primary output)
    raster.ts         # PNG / WebP rendering
    pdf.ts            # PDF export
    index.ts          # barrel
  presets/
    index.ts          # six built-in presets + registration
  plugins/
    index.ts          # plugin registration system
  validation/
    scan-validator.ts # independent decode verification
    index.ts          # barrel
```

## Determinism

Seed is computed as:

```
payloadHash = hashStringToSeed(data)          # FNV-1a
userSeed    = options.seed ?? hash(foreground + background)
seed        = combineSeeds(payloadHash, userSeed)  # xorshift128+ init
```

`buildTreatmentPlan` uses the seeded RNG to place connectors and micro-details deterministically. `getModuleShapeForCell` hashes `seed + "row,col"` for per-cell shape assignment, so the same cell always gets the same shape regardless of iteration order.

## Density-Aware Simplification

High-density matrices get simpler treatments so connectors/micro-details don't interfere with scanning:
- **low:** full frequencies
- **medium:** connector/micro-detail frequency capped at 2
- **high:** frequency capped at 1, finder layers capped at 3

## Validation Gate

`generate()` calls `assertScanReliability(svg, data)`. With no decoder available, validation is skipped gracefully (environment limitation, not unreliable QR). On decode failure, it throws `ScanReliabilityError` unless `skipValidation` is set, in which case it falls back to `architectural-minimal` with a fresh seed and re-validates once.

## What Is NOT Supported (by design)

- Central logos or arbitrary cutouts (destroys encoded modules).
- Quiet-zone decoration (breaks scanning).
- Gradients (not print-safe).
- More than two colours (dilutes identity).
- `batch` (does not exist in `@vesk/runtime`).
- Regex-based source manipulation (not applicable — no compiler changes).

## Compatibility

| vesk-qr | @vesk/runtime | @vesk/types | Node |
|---|---|---|---|
| 0.1.0 | >= 0.2.50 | >= 0.2.92 | >= 20 |
