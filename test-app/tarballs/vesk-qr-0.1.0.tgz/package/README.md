# vesk-qr

Cofoundr Generative QR Code Library — architectural QR geometry for the Vesk ecosystem.

Production-quality generative QR codes independent from visual rendering: encoding (versions 1–40, EC L/M/Q/H, numeric/alphanumeric/byte, URL, vCard, Wi-Fi), Cofoundr's proprietary architectural design system (module shapes, nested-square finders, architectural connectors, micro-details, alignment patterns), six presets as configs of one engine, deterministic seed-based generation, SVG primary output with PNG/WebP/PDF export, independent scan validation with reject-or-fallback gate, and a plugin system for custom renderers/effects/colours/exports.

**Peer dependencies:** `@vesk/runtime` (>= 0.2.50), `@vesk/types` (>= 0.2.92).  
**Optional peer:** `canvas` (^2.11.0) for PNG/WebP export in Node.

## Installation

```bash
npm install vesk-qr
```

For PNG/WebP export in Node:

```bash
npm install canvas
```

## Quick Start

```ts
import { CofoundrMatrix } from "vesk-qr";

const qr = await CofoundrMatrix.generate({
  data: "https://cofoundr.ng/certificate/abc123",
  style: { preset: "architectural" },
  colors: { foreground: "#111111", background: "#FFFFFF" },
  options: { errorCorrection: "H", margin: 4, size: 1200, seed: 48291 },
});

const svg = qr.toSVG();        // SVG markup string
const png = await qr.toPNG();  // Uint8Array
const webp = await qr.toWebP(); // Uint8Array
const pdf = await qr.toPDF();  // Uint8Array
```

## Works Everywhere (Universal)

The **SVG output** is the universal format — it works in every JavaScript environment
with zero dependencies beyond `@vesk/runtime` and `@vesk/types`:

```ts
import { CofoundrMatrix } from "vesk-qr";

// Works in: Edge, Node, browser, Vesk SSR, Cloudflare Workers, Deno, Bun
const qr = await CofoundrMatrix.generate({
  data: "https://cofoundr.ng",
  options: { seed: 42 },
});

const svg = qr.toSVG(); // string — always available
```

## By Environment

| Environment | `toSVG()` | `toPNG()` | `toWebP()` | `toPDF()` | Notes |
|---|---|---|---|---|---|
| **Edge Functions**<br>(Vercel Edge, Cloudflare Workers, Deno Deploy) | ✅ | ❌ | ❌ | ✅ | No `canvas`. Use SVG/PDF only. |
| **Node.js Serverless**<br>(Vercel Node, AWS Lambda, GCP Functions) | ✅ | ✅* | ✅* | ✅ | `canvas` optional peer; install it for PNG/WebP. |
| **Browser / Client**<br>(SPA, Vesk client) | ✅ | ✅* | ✅* | ✅ | Uses native `<canvas>` / `OffscreenCanvas`. |
| **Vesk SSR**<br>(`.vsk` page components) | ✅ | ✅* | ✅* | ✅ | Generate during SSR; ship SVG as static HTML. |
| **Deno / Bun** | ✅ | ❌* | ❌* | ✅ | No `canvas` native module. Use SVG/PDF. |

*\* Requires the `canvas` package in Node, or native `<canvas>` / `OffscreenCanvas` in the browser.*

### Edge Functions (Vercel Edge, Cloudflare Workers, Deno Deploy)

Edge runtimes are V8 isolates without Node.js built-ins or native addons. Use **SVG only**:

```ts
// ✅ Works on Edge
import { CofoundrMatrix } from "vesk-qr";

export default async function handler(req: Request) {
  const qr = await CofoundrMatrix.generate({
    data: "https://cofoundr.ng",
    options: { seed: 42 },
  });

  const svg = qr.toSVG();

  return new Response(svg, {
    headers: { "content-type": "image/svg+xml" },
  });
}
```

**Do not call `toPNG()` or `toWebP()` on Edge** — they require the `canvas` native module and will throw `CanvasUnavailableError`. Use `toSVG()` (always available) or `toPDF()` (pure JS, no canvas needed).

### Node.js Serverless (Vercel Node, AWS Lambda, GCP Functions)

Full export support is available. Install `canvas` for PNG/WebP:

```bash
npm install canvas
```

```ts
// ✅ Works on Node serverless
import { CofoundrMatrix } from "vesk-qr";

const qr = await CofoundrMatrix.generate({
  data: "https://cofoundr.ng",
  options: { seed: 42 },
});

const svg = qr.toSVG();
const png = await qr.toPNG();   // requires `canvas`
const webp = await qr.toWebP(); // requires `canvas`
const pdf = await qr.toPDF();   // always available
```

If `canvas` is not installed, `toPNG()`/`toWebP()` throw `CanvasUnavailableError` with a clear message. SVG and PDF still work without it.

### Browser / Client-Side (SPA, Vesk Client)

Uses native `<canvas>` or `OffscreenCanvas` — no `canvas` npm package needed:

```ts
// ✅ Works in browser
import { Qr } from "vesk-qr/components/Qr";

const svgElement = await Qr({ data: "https://cofoundr.ng", options: { size: 300 } });
document.body.appendChild(svgElement);
```

Or generate SVG and inject it:

```ts
const qr = await CofoundrMatrix.generate({ data: "…", options: { seed: 42 } });
document.getElementById("qr")!.innerHTML = qr.toSVG();
```

### Vesk Apps (`.vsk` Components)

Generate during SSR and ship the SVG as static HTML:

```vsk
import { CofoundrMatrix } from "vesk-qr"
import { RawHtml } from "vesk-qr/components/RawHtml"

async component QrBadge(props: { data: string }) {
  const qr = await CofoundrMatrix.generate({
    data: props.data,
    style: { preset: "architectural" },
    options: { size: 300, seed: 42 },
  })

  <div class="qr-badge">
    <RawHtml svg={qr.toSVG()} />
  </div>
}
```

Or use the `Qr` component directly:

```vsk
import { Qr } from "vesk-qr/components/Qr"

component QrBadge(props: { data: string }) {
  <Qr data={props.data} options={{ size: 300, seed: 42 }} />
}
```

## Quick Reference: Which Entry Point?

| Import | Best for |
|---|---|
| `vesk-qr` | Universal — works everywhere (SVG + PDF always, PNG/WebP if canvas available) |
| `vesk-qr/client` | Browser-only — PNG/WebP via native `<canvas>` |
| `vesk-qr/server` | Node-only — SVG + PDF; PNG/WebP via `canvas` package |
| `vesk-qr/components/Qr` | Vesk `.vsk` components |
| `vesk-qr/components/RawHtml` | Raw SVG injection in Vesk templates |

> **Rule of thumb:** If you're unsure what runtime your code will run on, use `toSVG()` from the main `vesk-qr` entry. It works everywhere without any optional dependencies.

## In a Vesk App

### Option 1: Generate inline in the component body (recommended)

Since `CofoundrMatrix.generate()` is async, use an `async component` and `await` it during SSR. The SVG is generated server-side and shipped as static HTML:

```vsk
import { CofoundrMatrix } from "vesk-qr"

async component QrBadge(props: { data: string }) {
  const qr = await CofoundrMatrix.generate({
    data: props.data,
    style: { preset: "architectural" },
    colors: { foreground: "#111111", background: "#FFFFFF" },
    options: { errorCorrection: "H", margin: 4, size: 300, seed: 42 },
  })

  <div class="qr-badge">
    // Vesk escapes `{expr}` bindings but does NOT escape component call
    // return values, so RawHtml injects the SVG as raw HTML.
    <RawHtml svg={qr.toSVG()} />
  </div>
}
```

```ts
import { RawHtml } from "vesk-qr/components/RawHtml"
```

### Option 2: Use the `Qr` component directly

```vsk
import { Qr } from "vesk-qr/components/Qr"

component QrBadge(props: { data: string }) {
  <Qr data={props.data} options={{ size: 300, seed: 42 }} />
}
```

`Qr` follows the lucide-vesk component ABI: `(props, registry?, scope?) => string | Element | null`. It returns an SVG string on the server and an SVG element on the client.

### Option 3: Programmatic TS usage

```ts
import { Qr } from "vesk-qr/components/Qr"

const svg = await Qr({ data: "https://cofoundr.ng/x", options: { size: 300 } })
// svg is a string on the server, an SVGElement on the client
```

## API Reference

### `CofoundrMatrix.generate(options)` → `Promise<QRResult>`

```ts
const qr = await CofoundrMatrix.generate({
  data: string,                       // URL, vCard, Wi-Fi, or plain text (required)
  style?: StyleConfig,                // preset + shape + finder + connectors + details
  colors?: ColorConfig,               // foreground / background
  options?: QRCodeOptions,            // EC level, margin, size, seed, version, …
})
```

`QRResult` methods:

| Method | Returns | Notes |
|---|---|---|
| `toSVG()` | `string` | SVG markup (always available) |
| `toPNG()` | `Promise<Uint8Array>` | Requires `canvas` in Node; `<canvas>` in browser |
| `toWebP()` | `Promise<Uint8Array>` | Falls back to PNG if WebP unsupported |
| `toPDF()` | `Promise<Uint8Array>` | Valid PDF with embedded SVG |
| `getMatrix()` | `boolean[][]` | Deep copy of the raw module matrix |
| `getMetadata()` | `QRMetadata` | version, EC, moduleCount, size, margin, seed, preset |
| `getSeed()` | `number` | The seed used (useful when none was supplied) |
| `getPreset()` | `string` | The preset name used |

### `generate(options)` — functional shorthand

Identical to `CofoundrMatrix.generate()`. Imported from `"vesk-qr"` or `"vesk-qr/client"` / `"vesk-qr/server"`.

### Subpath exports

| Import | Contents |
|---|---|
| `vesk-qr` | `CofoundrMatrix`, `generate`, `Qr`, `RawHtml`, types, errors, presets, plugins, validation |
| `vesk-qr/client` | Browser entry (PNG/WebP via native `<canvas>` or `OffscreenCanvas`) |
| `vesk-qr/server` | Node entry (SVG + PDF; PNG/WebP require `canvas`) |
| `vesk-qr/presets` | `presets`, `getPreset`, `registerPreset`, `listPresets` |
| `vesk-qr/plugins` | `registerPlugin`, `Plugin` interface |
| `vesk-qr/validation` | `validateScan`, `assertScanReliability` |
| `vesk-qr/errors` | `QRError`, `QREncodingError`, `ScanReliabilityError`, `InvalidConfigError`, `CanvasUnavailableError` |
| `vesk-qr/components/Qr` | `Qr` Vesk component helper |
| `vesk-qr/components/RawHtml` | `RawHtml` raw SVG injection component |

## Style Options

```ts
interface StyleConfig {
  preset?: "architectural" | "architectural-minimal" | "architectural-technical" |
           "architectural-micro" | "architectural-structural" | "architectural-monochrome" | "custom"
  module?: "square" | "small-square" | "rounded-square" | "micro-square" | "circle" | "rectangle" | "combination"
  finder?: "nested-square" | "standard"
  connectors?: boolean
  microDetails?: boolean
  connectorFrequency?: 0 | 1 | 2 | 3
  microDetailFrequency?: 0 | 1 | 2 | 3
  finderLayers?: 2 | 3 | 4 | 5
  monochrome?: boolean
}

interface ColorConfig {
  foreground?: string   // CSS colour, default "#111111"
  background?: string   // CSS colour, default "#FFFFFF"
}

interface QRCodeOptions {
  errorCorrection?: "L" | "M" | "Q" | "H"   // default "H"
  margin?: number                             // default 4 (QR spec minimum)
  size?: number                               // default 1200
  seed?: number                               // auto-generated if omitted
  version?: number                            // 1–40, auto-selected if omitted
  transparentBackground?: boolean             // default false
  skipValidation?: boolean                    // default false (not recommended)
}
```

## Six Presets

All presets are configurations of the same engine — not separate implementations:

| Preset | Modules | Finders | Connectors | Details | Monochrome | Best for |
|---|---|---|---|---|---|---|
| `architectural` | rounded-square | nested-square | yes | yes | no | Primary Cofoundr identity |
| `architectural-minimal` | square | nested-square | no | no | no | Clean, scannable |
| `architectural-technical` | rectangle | nested-square | yes | yes | no | Circuit-board aesthetic |
| `architectural-micro` | micro-square | nested-square | no | yes | no | High-density data |
| `architectural-structural` | square | nested-square | no | no | no | Strong nested finders |
| `architectural-monochrome` | square | nested-square | no | no | yes | Pure black & white |

```ts
import { presets } from "vesk-qr/presets"

presets.architectural
presets["architectural-technical"]
// Register your own:
registerPreset("my-brand", { module: "rounded-square", finder: "nested-square", … })
```

## Complete Variant Catalog

Module borders are **NOT statically square** — seven module shapes are supported, plus six presets, four EC levels, and arbitrary color configurations.

### Module Shapes (7)

| Shape | Value | Description |
|---|---|---|
| Square | `square` | Solid filled square, full module size |
| Small Square | `small-square` | ~70% scale square, centered |
| Rounded Square | `rounded-square` | Square with ~20% corner radius (architectural default) |
| Micro Square | `micro-square` | ~40% scale tiny square, centered |
| Circle | `circle` | Inscribed circle in the cell |
| Rectangle | `rectangle` | Wide trace, alternates horizontal/vertical by position |
| Combination | `combination` | Seeded random mix of all shapes above |

### Presets (6)

All presets are configurations of the same engine:

| Preset | Modules | Finders | Connectors | Details | Monochrome | Best for |
|---|---|---|---|---|---|---|
| `architectural` | rounded-square | nested-square | yes | yes | no | Primary Cofoundr identity |
| `architectural-minimal` | square | nested-square | no | no | no | Clean, scannable |
| `architectural-technical` | rectangle | nested-square | yes | yes | no | Circuit-board aesthetic |
| `architectural-micro` | micro-square | nested-square | no | yes | no | High-density data |
| `architectural-structural` | square | nested-square | no | no | no | Strong nested finders |
| `architectural-monochrome` | square | nested-square | no | no | yes | Pure black & white |

### Error Correction Levels (4)

| Level | Value | Use case |
|---|---|---|
| L (Low) | `"L"` | ~7% redundancy, maximum data capacity |
| M (Medium) | `"M"` | ~15% redundancy, balanced |
| Q (Quartile) | `"Q"` | ~25% redundancy, good for print |
| H (High) | `"H"` | ~30% redundancy, maximum damage resistance |

### Color Configurations

Foreground and background are independent CSS color strings. Default foreground `#111111`, default background `#FFFFFF`.

- **Custom colors**: any CSS color pair (e.g. `#FF6B35` on `#2C3E50`)
- **Monochrome**: forces `#000000` foreground and `#FFFFFF` background regardless of `colors` config

### Determinism

Same payload + config + seed → identical SVG output every time:

```ts
const a = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } })
const b = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } })
a.toSVG() === b.toSVG() // true
```

Omit `seed` and one is generated and recorded via `qr.getSeed()`.

## Playground Demo

See `playground/index.html` for an interactive browser demo covering all shapes, presets, EC levels, colors, sizes, and seeds with SVG/PNG/WebP/PDF download.

## Payload Helpers

```ts
import { CofoundrMatrix } from "vesk-qr"

CofoundrMatrix.buildURL("https://cofoundr.ng/x")
// { type: "url", data: "https://cofoundr.ng/x" }

CofoundrMatrix.buildVCard({ name: "Ada", org: "Cofoundr", email: "ada@cofoundr.ng" })
// { type: "vcard", data: "BEGIN:VCARD\n..." }

CofoundrMatrix.buildWiFi({ ssid: "Guest", password: "pw123", auth: "WPA" })
// { type: "wifi", data: "WIFI:T:WPA;S:Guest;P:pw123;;" }

CofoundrMatrix.buildText("Hello, Cofoundr!")
// { type: "text", data: "Hello, Cofoundr!" }
```

Pass the `data` field to `generate()`:

```ts
const payload = CofoundrMatrix.buildURL("https://cofoundr.ng/cert/123")
const qr = await CofoundrMatrix.generate({ data: payload.data, options: { seed: 42 } })
```

## Determinism

Same payload + config + seed → identical SVG output:

```ts
const a = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } })
const b = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } })
a.toSVG() === b.toSVG() // true
```

Omit `seed` and one is generated and recorded via `qr.getSeed()`.

## Scan Validation

Every generated QR is decoded by an independent decoder (@zxing). If decoding fails, `generate()` throws `ScanReliabilityError` unless `skipValidation` is set:

```ts
try {
  const qr = await CofoundrMatrix.generate({ data: "…", options: { seed: 42 } })
} catch (err) {
  if (err instanceof ScanReliabilityError) {
    // QR failed independent decode verification
  }
}
```

To manually validate:

```ts
import { validateScan } from "vesk-qr/validation"

const result = await validateScan(qr.toSVG(), "expected payload")
result.valid   // boolean
result.decoded // string | null
result.error   // string | null
```

## Plugin System

Extend rendering with custom modules, finders, colours, and exports:

```ts
import { registerPlugin, Plugin } from "vesk-qr/plugins"

const myPlugin: Plugin = {
  name: "my-brand",
  version: "1.0.0",
  renderModule: (ctx) => { /* return QRShapeOp[] */ },
  colourSystem: (colors) => ({ foreground: "#ff0000", background: "#ffffff" }),
}

registerPlugin(myPlugin)
```

See `API-SPECIFICATION.md` for the full type reference.

## Tests

```bash
npm test        # unit suite
npm run check   # typecheck + tests + build
```

## Design

See `DESIGN.md` for the design rationale, and `DESIGN-SYSTEM.md` for Cofoundr's geometric identity rules.
