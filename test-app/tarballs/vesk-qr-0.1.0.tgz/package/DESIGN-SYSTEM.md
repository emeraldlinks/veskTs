# vesk-qr — Design System

> Cofoundr proprietary QR visual identity. The geometric language that makes a
> Cofoundr QR recognisable without a logo.

## 1. Visual Direction

The design language communicates:

- **Precision** — every line, dot, and module is placed on a strict grid.
- **Architecture** — nested structures, blueprint-inspired connectors.
- **Engineering** — circuit-board routing, structural connections.
- **Technology** — clean, high-contrast, digital-native.
- **Minimalism** — no excess, no decoration for decoration's sake.
- **Structural intelligence** — the geometry *is* the brand.

The QR identity must be recognisable **without a logo**. Cofoundr emerges from
the geometry itself.

## 2. Strict Brand Restrictions

Do **not** introduce:

| Forbidden | Reason |
|---|---|
| Infinity symbols | Cliché, not architectural |
| Central logos | Violates QR spec (center is data) |
| Brand icons / mascots | Decorative, not geometric |
| Generic QR templates | Not proprietary |
| Unnecessary gradients | Not print-safe, not minimal |
| Excessive colours | Dilutes identity |
| Quiet-zone decoration | Breaks scanning, violates spec |
| Large empty centre | Destroys encoded modules |

## 3. Module System

Configurable geometric modules that preserve QR information and stay within safe
rendering boundaries.

| Module | Visual | Use case |
|---|---|---|
| `square` | Solid filled square | Standard data modules |
| `small-square` | Solid square at ~70% scale | Reduced visual weight |
| `rounded-square` | Square with rounded corners (~20% radius) | Softer architectural feel |
| `micro-square` | Tiny square at ~40% scale | High-density areas, micro-details |
| `circle` | Filled circle | Contrast against square modules |
| `rectangle` | Wide or tall rectangle | Connector-aligned modules |
| `combination` | Mix of above per seed | Generative variation |

**Rule**: Module shape is chosen per-cell by the generative engine, but *never*
for finder/alignment/timing/format/version modules (those are functional and
must remain scannable as standard patterns). Data modules may be stylised
within safe bounds.

## 4. Finder Pattern System

The three primary QR finder patterns (top-left, top-right, bottom-left) retain
their required structural and positional properties. The Cofoundr finder is a
**nested square structure**:

```
┌─────────────────────┐
│  outer dark square  │   ← 7×7 standard finder outer boundary
│  ┌───────────────┐  │
│  │ white gap     │  │   ← 1-module white separator
│  │ ┌─────────┐   │  │
│  │ │ dark    │   │  │   ← 3×3 dark core
│  │ │ inner   │   │  │
│  │ │ square  │   │  │
│  │ └─────────┘   │  │
│  │ white ring    │  │   ← 1-module white ring
│  └───────────────┘  │
│  outer dark ring   │   ← 1-module dark ring
└─────────────────────┘
```

- **Nested square structures**: outer dark ring → white ring → dark core →
  optional micro inner detail (configurable).
- **Multiple concentric geometric layers**: 3–5 rings depending on preset.
- **Controlled spacing**: consistent 1-module gaps between layers.
- **Consistent proportions**: all three finders identical in structure.
- **Strong visual contrast**: dark on light, no grey halfway tones.

The finder keeps its 7×7 (or version-appropriate) structural footprint. The
nested styling is painted *over* the standard finder modules without shifting
any boundary.

## 5. Alignment Patterns

Preserved per QR spec. Exact encoded structural requirements are maintained.
Restrained visual customisation is allowed:

- Same nested-square language as finders, but scaled down.
- No connectors inside alignment pattern boundaries.
- Micro-details permitted outside the alignment footprint.

## 6. Architectural Connectors

Fine geometric lines inspired by architectural blueprints, circuit board routing,
technical drawings, structural connection diagrams.

**Rules:**
- Decorative only.
- **Never obscure encoded modules** — connectors run in the white space between
  modules, never over a dark data cell.
- **Never compromise decoding** — connectors are thin (≤0.5 module width), light
  contrast (or same colour as foreground at low opacity), and avoid finder/
  alignment/timing patterns.
- Configurable: frequency, thickness, colour, angle (horizontal/vertical/diagonal).

Connector placement is deterministic from the seed: a pseudo-random walk through
the inter-module whitespace, constrained to safe corridors.

## 7. Micro-Details

Controlled insertion of small geometric elements:

- Small geometric dots (1–2 modules).
- Micro-squares (sub-module).
- Short technical lines (1 module long).
- Geometric corner ornaments (L-brackets at data-module corners).

**Placement rules:**
- Only on dark data modules (never on light cells — that would invert the
  encoding).
- Never in the quiet zone.
- Never overlapping finder/alignment/timing patterns.
- Frequency configurable (0 = none, 1 = sparse, 2 = dense).

## 8. Presets

All six presets are configurations of the **same rendering engine**:

| Preset | Modules | Finder | Connectors | Micro-details | Colours |
|---|---|---|---|---|---|
| `architectural` | rounded-square | nested-square (3 layers) | on | on (sparse) | foreground + background |
| `architectural-minimal` | square | nested-square (2 layers) | off | off | monochrome |
| `architectural-technical` | rectangle + square | nested-square (3 layers) | on (dense) | on (sparse) | foreground + background |
| `architectural-micro` | micro-square + circle | nested-square (4 layers) | off | on (dense) | foreground + background |
| `architectural-structural` | square | nested-square (5 layers) | off | off | monochrome |
| `architectural-monochrome` | square | nested-square (3 layers) | off | off | #000000 + #FFFFFF |

## 9. Colour System

- **Foreground**: default `#111111` (near-black, not pure black for architectural softness).
- **Background**: default `#FFFFFF` (white).
- **Monochrome mode**: forces `#000000` / `#FFFFFF`.
- No gradients. No more than 2 colours (foreground + background).

## 10. Dimensions & Quiet Zone

- **Size**: configurable (default 1200px for SVG, scales to output).
- **Margin (quiet zone)**: 4 modules minimum per QR spec, configurable.
- **Background transparency**: supported (SVG only; raster defaults to opaque).
- The quiet zone is **never decorated** — no connectors, no micro-details, no
  finder styling extends into it.

## 11. Determinism

Same payload + config + seed → identical output. The generative engine uses a
seeded PRNG (xorshift128+) seeded from:
- The payload hash (SHA-256 of the data string).
- The user-supplied seed (default: random, but recorded in output).

Different seeds may change:
- Module shape distribution.
- Connector placement/frequency.
- Micro-detail placement.
- Finder layer count.

Different seeds never change:
- Which cells are dark vs light.
- The encoded payload.
- QR version or error correction level.
- Finder/alignment/timing positions.
