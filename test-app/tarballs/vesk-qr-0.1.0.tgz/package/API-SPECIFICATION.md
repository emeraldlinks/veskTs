# vesk-qr — API Specification

> Public API surface for the Cofoundr Generative QR Code Library.

## 1. Installation

```bash
npm install vesk-qr
```

Peer dependencies: `@vesk/runtime` (>= 0.2.50), `@vesk/types` (>= 0.2.92).
For PNG/WebP export in Node, also install `canvas` (optional peer).

## 2. Main Entry

```ts
import { CofoundrMatrix } from 'vesk-qr';
// or
import { generate, QRResult } from 'vesk-qr';
```

### 2.1 `CofoundrMatrix.generate(options)` → `Promise<QRResult>`

Generates a QR code and returns a result object with export methods.

```ts
const qr = await CofoundrMatrix.generate({
  data: "https://cofoundr.ng",

  style: {
    preset: "architectural",
    module: "rounded-square",
    finder: "nested-square",
    connectors: true,
    microDetails: true,
  },

  colors: {
    foreground: "#111111",
    background: "#FFFFFF",
  },

  options: {
    errorCorrection: "H",
    margin: 4,
    size: 1200,
    seed: 48291,
  },
});

const svg = qr.toSVG();           // string
const png = await qr.toPNG();     // Uint8Array
const webp = await qr.toWebP();   // Uint8Array
const pdf = await qr.toPDF();     // Uint8Array
const matrix = qr.getMatrix();    // boolean[][]
```

### 2.2 `generate()` — functional shorthand

```ts
import { generate } from 'vesk-qr';
const qr = await generate({ ...same options... });
```

Identical to `CofoundrMatrix.generate()`.

## 3. Types

### 3.1 `GenerateOptions`

```ts
interface GenerateOptions {
  /** The payload to encode. URL, vCard, Wi-Fi, or plain text. */
  data: string;

  /** Visual style configuration. */
  style?: StyleConfig;

  /** Foreground and background colours. */
  colors?: ColorConfig;

  /** Encoding and rendering options. */
  options?: QRCodeOptions;
}
```

### 3.2 `StyleConfig`

```ts
interface StyleConfig {
  /** One of the six presets, or 'custom' for full manual control. */
  preset?:
    | "architectural"
    | "architectural-minimal"
    | "architectural-technical"
    | "architectural-micro"
    | "architectural-structural"
    | "architectural-monochrome"
    | "custom";

  /** Module shape for data modules. */
  module?:
    | "square"
    | "small-square"
    | "rounded-square"
    | "micro-square"
    | "circle"
    | "rectangle"
    | "combination";

  /** Finder pattern style. */
  finder?: "nested-square" | "standard";

  /** Whether to draw architectural connectors. */
  connectors?: boolean;

  /** Whether to draw micro-details. */
  microDetails?: boolean;

  /** Connector frequency: 0 (none) to 3 (dense). */
  connectorFrequency?: 0 | 1 | 2 | 3;

  /** Micro-detail frequency: 0 (none) to 3 (dense). */
  microDetailFrequency?: 0 | 1 | 2 | 3;

  /** Finder layer count: 2 to 5. */
  finderLayers?: 2 | 3 | 4 | 5;

  /** Whether to force monochrome rendering. */
  monochrome?: boolean;
}
```

### 3.3 `ColorConfig`

```ts
interface ColorConfig {
  /** Foreground (dark module) colour. Default "#111111". */
  foreground?: string; // CSS colour string
  /** Background (light module + quiet zone) colour. Default "#FFFFFF". */
  background?: string; // CSS colour string
}
```

### 3.4 `QRCodeOptions`

```ts
interface QRCodeOptions {
  /** Error correction level. Default "H". */
  errorCorrection?: "L" | "M" | "Q" | "H";

  /** Quiet zone width in modules. Default 4 (QR spec minimum). */
  margin?: number;

  /** Output size in pixels. Default 1200. */
  size?: number;

  /** Deterministic seed. If omitted, a random seed is generated and recorded. */
  seed?: number;

  /** Force a specific QR version (1–40). Omit for auto-selection. */
  version?: number;

  /** Background transparency (SVG/PDF only). Default false. */
  transparentBackground?: boolean;
}
```

### 3.5 `QRResult`

```ts
interface QRResult {
  /** SVG markup as a string. */
  toSVG(): string;

  /** PNG image as a Uint8Array. Requires canvas (Node) or <canvas> (browser). */
  toPNG(): Promise<Uint8Array>;

  /** WebP image as a Uint8Array. Requires canvas. */
  toWebP(): Promise<Uint8Array>;

  /** PDF document as a Uint8Array (SVG embedded). */
  toPDF(): Promise<Uint8Array>;

  /** The raw boolean matrix (true = dark module). */
  getMatrix(): boolean[][];

  /** Matrix metadata (version, size, EC level, module count). */
  getMetadata(): QRMetadata;

  /** The seed used (useful if none was supplied). */
  getSeed(): number;

  /** The preset name used. */
  getPreset(): string;
}

interface QRMetadata {
  version: number;           // 1–40
  errorCorrection: "L" | "M" | "Q" | "H";
  moduleCount: number;       // width = height of the matrix
  dataModules: number;       // count of data (non-functional) modules
  size: number;              // output pixel size
  margin: number;            // quiet zone modules
  seed: number;              // seed used
  preset: string;            // preset name
}
```

## 4. Preset Management

```ts
import { presets, getPreset, registerPreset } from 'vesk-qr/presets';

// List all built-in presets
presets.architectural;
presets["architectural-minimal"];
// ...

// Resolve a preset by name (returns merged config)
const config = getPreset("architectural-technical");

// Register a custom preset
registerPreset("my-brand", {
  module: "rounded-square",
  finder: "nested-square",
  connectors: true,
  microDetails: true,
  connectorFrequency: 2,
  microDetailFrequency: 1,
  finderLayers: 3,
  monochrome: false,
});
```

## 5. Plugin System

```ts
import { registerPlugin, Plugin } from 'vesk-qr/plugins';

interface Plugin {
  name: string;
  version: string;
  /** Render a single data module. Receives context, returns shape ops. */
  renderModule?: (ctx: ModuleRenderContext) => ShapeOp[];
  /** Render a finder pattern. */
  renderFinder?: (ctx: FinderRenderContext) => ShapeOp[];
  /** Render an alignment pattern. */
  renderAlignment?: (ctx: AlignmentRenderContext) => ShapeOp[];
  /** Add decorative effects after all modules are rendered. */
  decorate?: (ctx: DecorateContext) => ShapeOp[];
  /** Transform colours. */
  colourSystem?: (colors: ColorConfig) => ColorConfig;
  /** Custom export adapter. */
  exportAdapter?: (format: string, svg: string) => Promise<Uint8Array> | string;
}

registerPlugin(myPlugin);
```

## 6. Validation / Scan Testing

```ts
import { validateScan, ScanResult } from 'vesk-qr/validation';

// Check that a generated QR decodes to its original payload
const result: ScanResult = await validateScan(qr, expectedPayload);
result.valid;       // boolean
result.decoded;     // string (what the decoder read)
result.error;       // error message if invalid
```

`validateScan` is automatically called during `generate()`. If it fails, the
generator throws a `ScanReliabilityError` unless `options.skipValidation` is
set (not recommended).

## 7. Errors

```ts
import { QREncodingError, ScanReliabilityError, InvalidConfigError } from 'vesk-qr/errors';
```

- `QREncodingError` — the payload cannot be encoded (too long for version/EC).
- `ScanReliabilityError` — the generated QR failed independent decode verification.
- `InvalidConfigError` — the options are invalid or would produce an unscannable QR.

## 8. Usage Examples

### URL payload

```ts
const qr = await CofoundrMatrix.generate({
  data: "https://cofoundr.ng/certificate/abc123",
  style: { preset: "architectural" },
  colors: { foreground: "#111111", background: "#FFFFFF" },
  options: { errorCorrection: "H", margin: 4, size: 1200, seed: 48291 },
});
const svg = qr.toSVG();
```

### vCard payload

```ts
const qr = await CofoundrMatrix.generate({
  data: "BEGIN:VCARD\nVERSION:3.0\nFN:Cofoundr Member\nORG:Cofoundr\nEMAIL:hello@cofoundr.ng\nEND:VCARD",
  style: { preset: "architectural-minimal" },
  options: { errorCorrection: "M", size: 800 },
});
```

### Wi-Fi configuration payload

```ts
const qr = await CofoundrMatrix.generate({
  data: "WIFI:T:WPA;S:MyNetwork;P:password123;;",
  style: { preset: "architectural-technical" },
  options: { errorCorrection: "Q", size: 1000 },
});
```

### Deterministic output

```ts
// Same payload, config, seed → identical SVG every time
const a = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } });
const b = await CofoundrMatrix.generate({ data: "hello", options: { seed: 12345 } });
a.toSVG() === b.toSVG(); // true
```

### With `@vesk/testing` in a Vesk app

```ts
import { renderComponent } from '@vesk/testing';
// The QR component renders SVG; mount() and assert on the SVG output.
```

## 9. Vesk Component Usage

In a `.vsk` component, call `generate()` inside `load()` or an async context,
then render the SVG:

```vsk
component QrBadge {
  const &[svg] = track("")
  const data = "https://cofoundr.ng/member/42"

  // Server-side: generate and store SVG
  const qr = await CofoundrMatrix.generate({ data, ... })
  svg = qr.toSVG()

  <div class="qr-badge">
    <div dangerouslySetInnerHTML={{ __html: svg }} />
  </div>
}
```

> Note: `dangerouslySetInnerHTML` is the Vesk escape hatch for injecting trusted
> SVG markup. The SVG is generated by this library and is free of user content
> beyond the payload string itself (which is QR-encoded, not rendered as HTML).

## 10. Version Compatibility

| vesk-qr | @vesk/runtime | @vesk/types | Node |
|---|---|---|---|
| 0.1.0 | >= 0.2.50 | >= 0.2.92 | >= 20 |

## 11. What Is NOT Supported (by design)

- Central logos or arbitrary cutouts (destroys encoded modules, violates brand).
- Quiet-zone decoration (breaks scanning).
- Gradients (not print-safe).
- More than two colours (dilutes identity).
- `batch` (does not exist in `@vesk/runtime`).
- Regex-based source manipulation (not applicable here — no compiler changes).
