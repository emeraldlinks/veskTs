# vesk-qr — Implementation Plan

> Phase-by-phase build plan for the Cofoundr Generative QR Code Library.
> Follows the 8-phase workflow mandated by the project requirements.

## Phase 1 — Repository Inspection ✅ (COMPLETE)

Completed. Key findings:

- Vesk is a monorepo at `/root/vesk` with packages: types, adapter, cli,
  compiler, runtime, lsp, create-vesk, plugin-tailwind, prettier-plugin,
  lucide-vesk, plugin-multipart, testing, adapters/vite, agentic.
- `vesk-libs/` at `/root/vesk-libs` is a separate program outside the vesk repo,
  with existing libraries `vesk-auth` and `vesk-paystack` as reference patterns.
- Library conventions: unscoped npm name (`vesk-auth`), peer deps on
  `@vesk/runtime` + `@vesk/types`, `tsconfig.json` + `tsconfig.build.json`,
  `src/` + `test/`, `DESIGN.md` + `README.md`, `npm test` runs `tsx --test`.
- Vesk runtime: reactivity via `track()`/`get()`/`set()`, cells via
  `const &[x] = track(0)`, `useFetch` for data, no `batch`, no VDOM.
- No compiler changes needed for this library — it is a standalone package.

## Phase 2 — Architecture Documents ✅ (COMPLETE)

- `ARCHITECTURE.md` — subsystem boundaries, Vesk compatibility, limitations.
- `DESIGN-SYSTEM.md` — Cofoundr geometric language, brand restrictions,
  module/finder/connector/micro-detail specifications, presets.
- `API-SPECIFICATION.md` — public API, types, presets, plugins, validation,
  errors, usage examples, Vesk component usage.
- `IMPLEMENTATION-PLAN.md` — this document.

## Phase 3 — Core Implementation (QR Encoding + Matrix)

### 3.1 Package scaffolding
- `package.json` — name `vesk-qr`, version `0.1.0`, peer deps `@vesk/runtime`,
  `@vesk/types`, optional peer `canvas` for Node raster export.
- `tsconfig.json` / `tsconfig.build.json` — strict TS, ES2022, bundler
  module resolution, declaration output.
- `src/index.ts` — main barrel exporting `CofoundrMatrix`, `generate`,
  `QRResult`, types, errors.
- `src/index.client.ts` / `src/index.server.ts` — client/server barrel split
  (canvas-dependent exports only on client).
- Subpath exports: `./presets`, `./plugins`, `./validation`, `./errors`.

### 3.2 QR encoding integration
- Add `qr-code-styling` as a dependency (encoding-only usage).
- `src/encoding/qr-encoder.ts` — wraps `qr-code-styling` encoder:
  - versions 1–40, auto version selection
  - EC levels L/M/Q/H
  - numeric, alphanumeric, byte, kanji modes
  - returns boolean module matrix + module type map
- `src/encoding/matrix.ts` — enriches encoder output into module map:
  - every cell: row, col, type (data/alignment/finder/timing/format/version/quiet),
    isFunctional, isDark
- `src/encoding/payload.ts` — payload builders: URL, vCard, Wi-Fi, plain text.

### 3.3 Module representation
- `ModuleMap` type: grid of `ModuleCell` records.
- `ModuleType` enum: DATA, ALIGNMENT, FINDER, TIMING, FORMAT, VERSION, QUIET.
- Pure functions to query the map: `isFunctional(cell)`, `isData(cell)`,
  `finderCoordinates(map)`, `alignmentCoordinates(map)`.

## Phase 4 — Generative Engine

### 4.1 Seeded PRNG
- `src/generative/seeded-rng.ts` — xorshift128+ PRNG:
  - `createSeededRNG(seed: number)` → `{ next(): number, nextInt(min, max): number }`
  - deterministic, reproducible, fast, no external deps.

### 4.2 Visual treatment plan
- `src/generative/treatment-plan.ts` — from payload hash + seed + config,
  produce:
  - module shape assignment per data cell (respecting safe bounds)
  - connector placement (coordinates, angle, thickness)
  - micro-detail placement (coordinates, type)
  - finder layer count
  - density-aware simplification (denser matrices → simpler treatments)

### 4.3 Determinism guarantee
- Same payload + config + seed → identical treatment plan.
- Seed derived from: SHA-256(data) ^ userSeed (or random if not supplied).
- Seed is recorded in `QRMetadata` and returned by `getSeed()`.

## Phase 5 — Geometric System + Rendering

### 5.1 Geometric system (`src/geometry/`)
- `modules.ts` — module shape renderers (pure, return shape ops):
  - square, small-square, rounded-square, micro-square, circle, rectangle
- `finder.ts` — nested-square finder pattern:
  - 3–5 concentric layers, 1-module gaps, consistent proportions
- `alignment.ts` — alignment pattern styling (restrained customisation)
- `connectors.ts` — architectural connector lines (decorative, safe corridors)
- `micro-details.ts` — dots, micro-squares, short lines, corner ornaments
- `generator.ts` — combines all geometry into a shape-op list from module map +
  treatment plan

### 5.2 Shape operations
- `ShapeOp` type: `{ kind: "rect" | "circle" | "line" | "path", x, y, w, h,
  r, ...style }`
- Pure geometry → shape ops (no DOM, no canvas).

### 5.3 SVG rendering (`src/rendering/svg.ts`)
- Primary output format.
- `<svg>` with `<rect>`, `<circle>`, `<line>`, `<path>` elements.
- Quiet zone = background rect only, never decorated.
- Configurable size, margin, colours, transparency.

### 5.4 Raster rendering (`src/rendering/raster.ts`)
- PNG and WebP via canvas.
- Node: `canvas` package (optional peer dependency).
- Browser: native `<canvas>` OffscreenCanvas or canvas element.
- Graceful degradation: throws clear error if canvas unavailable.

### 5.5 PDF export (`src/rendering/pdf.ts`)
- SVG embedded in a PDF document.
- Print-ready, vector output.
- Pure JS (no native PDF dependency — manual PDF wrapper around SVG data URI).

## Phase 6 — Validation (Scan Reliability)

### 6.1 Independent decode verification
- `src/validation/scan-validator.ts`:
  - Browser: `@zxing/browser` (BrowserQRCodeReader).
  - Node: `qrcode` or `@zxing/node` (or pure JS decoder).
  - Decodes the generated SVG/PNG and compares to original payload.
- `validateScan(qrResult, expectedPayload)` → `ScanResult { valid, decoded, error }`.

### 6.2 Reject-or-fallback gate
- If validation fails:
  - Throw `ScanReliabilityError` with details.
  - Optional auto-fallback: regenerate with simpler style (square modules,
    no connectors, no micro-details) and re-validate.
- Never return an unscannable QR silently.

### 6.3 Test matrix
- QR versions 1–40 (representative sample).
- EC levels L/M/Q/H.
- Module shapes: all 6.
- Finder styles: nested-square, standard.
- Payload lengths: short, medium, long, near-capacity.
- Unicode payloads.
- High-density codes (version 20+).
- Output dimensions: 200, 800, 1200, 2400.
- SVG and raster exports.
- Colour combinations: dark/light, monochrome, custom.

## Phase 7 — Presets + Plugins

### 7.1 Preset system (`src/presets/`)
- Six presets as configuration objects (not separate implementations).
- `presets/index.ts` — export all presets.
- `getPreset(name)`, `registerPreset(name, config)`.

### 7.2 Plugin system (`src/plugins/`)
- `Plugin` interface with optional hooks: renderModule, renderFinder,
  renderAlignment, decorate, colourSystem, exportAdapter.
- `registerPlugin(plugin)` / `getPlugins()`.
- Documented plugin interface.

## Phase 8 — Testing + Playground + Documentation

### 8.1 Unit tests (`src/**/*.test.ts`)
- Every module has tests: encoding, geometry, rendering, presets, plugins,
  validation, generative.
- Run via `npx tsx --test src/**/*.test.ts`.

### 8.2 Integration tests (`test/`)
- End-to-end: generate → export → decode → verify payload.
- Cross-preset, cross-EC, cross-version.
- Both statement-mode and expression-mode compatible (where applicable).

### 8.3 Playground (`playground/`)
- Single-page HTML/TS demo:
  1. URL/text input.
  2. Preset selector (6 presets).
  3. Geometric parameter sliders.
  4. Colour pickers.
  5. Generate button.
  6. Scan-test result (decode and show decoded text).
  7. SVG preview.
  8. Export buttons (SVG download, PNG download).
- Uses the actual library (not a separate renderer).

### 8.4 Documentation
- `README.md` — installation, quick start, API reference.
- `DESIGN.md` — design decisions (mirrors DESIGN-SYSTEM.md with rationale).
- All documented exports verified against source.

## Phase 9 — Definition of Done

- [ ] `npm run typecheck` clean (strict TS, no `any`).
- [ ] `npm run build` produces `dist/` with declarations.
- [ ] Unit tests pass (all `src/**/*.test.ts`).
- [ ] Integration tests pass (generate → decode → verify).
- [ ] Scan reliability: every preset × EC × version combination decodes correctly.
- [ ] Playground works: generate, scan-test, preview, export.
- [ ] README + DESIGN.md written, all imports verified to resolve from `dist/`.
- [ ] Entry added to `/root/vesk-libs/TODO.md` catalog.

## Release Order

`vesk-qr` is library #31+ in the `vesk-libs` catalog (after VeskAuth #1,
VeskPaystack #2, VeskChart #3). It is a standalone port with no dependencies on
other vesk-libs packages.
