# vesk-qr — Architecture Document

> Cofoundr Generative QR Code Library — Architectural Matrix (CAM)
> Part of the `vesk-libs` program, outside the `vesk` framework repo.
> Follows the Vesk library conventions documented in `/root/vesk-libs/TODO.md`.

## 1. Overview

`vesk-qr` is a production-quality, extensible QR code generation library that
establishes a proprietary geometric visual identity for Cofoundr. It is not a
conventional QR styling library; it is a generative graphics system built around
QR encoding standards and a distinctive architectural geometric language.

The library ships as an unscoped npm package `vesk-qr`, peer-depending on
`@vesk/runtime` and `@vesk/types`, consumable from Vesk apps (`.vsk` components
and plain TS/JS) and from plain Node.js / browser environments.

## 2. Design Principles

| Principle | Meaning for this library |
|---|---|
| **Standards-compliant encoding** | QR encoding follows ISO/IEC 18004. Versions 1–40, EC levels L/M/Q/H, numeric/alphanumeric/byte/kanji modes. No invented encoding rules. |
| **Encoding ⟂ rendering** | The QR encoder and the visual renderer are completely independent subsystems. The encoder produces a boolean matrix; the renderer paints it. |
| **Scan reliability first** | Every configuration is verified against an independent QR decoder. A configuration that cannot be decoded is rejected or falls back to a safe rendering. |
| **Deterministic / seed-based** | Same payload + config + seed = identical output. Different seeds may change visual treatments without changing encoded data. |
| **No central logo, no quiet-zone decoration** | The Cofoundr identity emerges from geometry alone. No infinity symbols, mascots, gradients, or excessive colours. The quiet zone is never decorated. |
| **Vesk-native** | Strict TypeScript, no `any`, tree-shakable exports, browser + Node compatible, server-authoritative where applicable, statement-mode-first where components are involved. |
| **Zero unnecessary dependencies** | One QR encoding dependency (`qr-code-styling`, encoding-only usage). Everything else is hand-written. |

## 3. Subsystem Boundaries

```
┌─────────────────────────────────────────────────────────────┐
│                     CofoundrMatrix API                      │
│  generate({ data, style, colors, options }) → QRResult      │
└──────────────┬──────────────────────────────────────────────┘
               │
   ┌───────────▼───────────┐
   │   Validation Layer    │  input schema, preset resolution,
   │   (validation/)       │  option sanitisation, safe defaults
   └───────────┬───────────┘
               │
   ┌───────────▼───────────┐
   │   QR Encoding Engine  │  qr-code-styling (encoding only)
   │   (encoding/)         │  versions 1–40, EC L/M/Q/H,
   │                       │  numeric / alphanumeric / byte
   └───────────┬───────────┘
               │  boolean matrix + metadata
   ┌───────────▼───────────┐
   │   Matrix Processing   │  module map, quiet zone,
   │   (matrix.ts)         │  alignment/finder coordinates
   └───────────┬───────────┘
               │
   ┌───────────▼───────────┐
   │   Generative Engine   │  seeded RNG, geometric
   │   (generative/)       │  distribution, density,
   │                       │  pattern consistency
   └───────────┬───────────┘
               │
   ┌───────────▼───────────┐
   │   Geometric System    │  module shapes, finder,
   │   (geometry/)         │  alignment, connectors,
   │                       │  micro-details
   └───────────┬───────────┘
               │  geometry description (shape ops)
   ┌───────────▼───────────┐
   │   Rendering Pipeline  │  SVG (primary), PNG,
   │   (rendering/)        │  WebP, PDF export
   └───────────┬───────────┘
               │  SVG string / buffer
   ┌───────────▼───────────┐
   │   Scan Validation     │  independent decoder
   │   (validation/)       │  reject-or-fallback gate
   └───────────────────────┘
```

### 3.1 QR Encoding Engine (`src/encoding/`)

Wraps `qr-code-styling`'s encoder for standards-compliant matrix generation.
Responsibilities:

- Accept raw data (string / bytes) + error correction level.
- Auto-select QR version (1–40) or accept an explicit version.
- Produce a boolean `moduleMatrix` (width × height) plus module type map
  (data, alignment, finder, timing, format, version, quiet).
- Expose payload helpers: URL, vCard, Wi-Fi, plain text.

The encoder never touches visual style. It knows nothing about colours, module
shapes, finder styling, or connectors.

### 3.2 Matrix Processing (`src/encoding/matrix.ts`)

Converts the raw encoder output into a rich module map where every cell carries:

- `row, col` coordinates
- `type`: `data` / `alignment` / `finder` / `timing` / `format` / `version` / `quiet`
- `isFunctional`: true for finder/alignment/timing/format/version (reserved by spec)
- `isDark`: the encoded bit

This map is the single contract between encoding and rendering.

### 3.3 Generative Engine (`src/generative/`)

A deterministic, seed-based procedural engine. Responsibilities:

- Seeded PRNG (xorshift128+, reproducible).
- Given a payload hash + seed, produce a "visual treatment plan":
  - Which module shapes to use where (within safe bounds).
  - Connector placement and frequency.
  - Micro-detail placement.
  - Density-aware variation (denser matrices get simpler treatments).
- The same payload + config + seed always yields the same plan.
- The plan never changes which cells are dark/light — only how they are drawn.

### 3.4 Geometric System (`src/geometry/`)

The Cofoundr architectural geometric language. Pure functions that take a module
map + treatment plan and emit a list of shape operations (rects, circles, lines,
dots). Responsibilities:

- **Module system**: square, small square, rounded square, micro-square, circle,
  rectangle, controlled combinations.
- **Finder pattern system**: nested square structures with concentric layers,
  controlled spacing, consistent proportions. The three finders keep their QR
  structural/positional properties.
- **Architectural connectors**: fine blueprint/circuit-board lines. Decorative
  only; never obscure encoded modules.
- **Micro-details**: dots, micro-squares, short lines, corner ornaments.
- **Alignment patterns**: preserved per spec, restrained customisation.

All geometry functions are pure and browser/Node agnostic (no `document`/`window`).

### 3.5 Rendering Pipeline (`src/rendering/`)

Accepts shape operations + colour config + dimensions and emits output.

- **SVG (primary)**: `<svg>` with `<rect>`, `<circle>`, `<line>`, `<path>`.
  Quiet zone rendered as background rect only — no decoration inside it.
- **PNG / WebP**: rasterised via Canvas (Node: `canvas` npm; browser: native
  `<canvas>`). Graceful degradation if canvas unavailable.
- **PDF**: SVG embedded in a PDF document (print-ready, vector).
- Colours: foreground, background, monochrome mode.
- Dimensions, margin, background transparency all configurable.

### 3.6 Validation Layer (`src/validation/`)

Independent QR decoding verification. Every generated QR (before it is handed to
the caller) is decoded by an independent decoder (e.g. `@zxing/browser` or a
Node port). If decoding fails against the original payload:

- The generator rejects the configuration with a clear error, OR
- Falls back to a safer rendering (simpler modules, fewer connectors).

This is non-negotiable: a beautiful unscannable QR is a failed implementation.

### 3.7 Preset System (`src/presets/`)

Six presets, all configurations of the same engine:

1. **architectural** — primary Cofoundr identity.
2. **architectural-minimal** — reduced geometric details.
3. **architectural-technical** — more pronounced connectors.
4. **architectural-micro** — more micro-squares and dots.
5. **architectural-structural** — stronger nested finder patterns.
6. **architectural-monochrome** — pure black-and-white.

### 3.8 Plugin System (`src/plugins/`)

Registered extension points:

- Custom module renderers, finder renderers, alignment renderers.
- Custom decorative effects, colour systems, generation strategies, export adapters.

The plugin interface is a plain object with `name`, `version`, and lifecycle
hooks. No tight coupling to the encoding engine.

## 4. Vesk Compatibility

- **Strict TypeScript**, `noImplicitAny`, `noUncheckedIndexedAccess`.
- **No `any`** anywhere in public or internal code.
- **Tree-shakable exports**: barrel at `src/index.ts`; subpath exports for
  `./presets`, `./plugins`, `./validation`.
- **Browser + Node**: no browser globals in core modules. Canvas usage guarded
  behind `typeof document !== 'undefined'` / `typeof window !== 'undefined'`.
- **Public types in `@vesk/types`**: QR-specific types are local to this package
  (not added to `@vesk/types`, which is framework-level). The package re-exports
  from `@vesk/types` where needed.
- **Statement mode first**: any `.vsk`-facing helpers are tested in both
  expression and statement mode.

## 5. Compatibility Limitations (documented)

- **PNG/WebP in Node**: requires the `canvas` native module (optional peer
  dependency). Without it, PNG/WebP export throws a clear error suggesting
  installation or use of SVG/PDF instead.
- **Canvas in browser**: requires `<canvas>` support (all modern browsers).
- **PDF export**: purely SVG-in-PDF; no text embedding beyond SVG text nodes.
- **Independent decoder**: the scan-validation step uses `@zxing/browser` in
  browser and a Node QR decoder in Node. If the decoder package is unavailable,
  validation is skipped with a warning (not a silent pass).
